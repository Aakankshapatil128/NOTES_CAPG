export class Associate {

    constructor(public associateId: string, public  associateName: string,  public associateEmailId:string,public  associateAddress:string ) {  }
}
