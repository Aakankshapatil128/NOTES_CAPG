export class Course {


  constructor(public courseId: string, public courseName: string, public fees: number,
    public duration: number, public courseType: string, public rating: number) { }

  
}
