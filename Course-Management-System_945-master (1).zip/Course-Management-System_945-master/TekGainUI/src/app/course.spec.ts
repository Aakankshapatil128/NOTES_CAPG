import { Course } from './course';

describe('Course', () => {
  
  
// Fill the code  for unit testing


});
