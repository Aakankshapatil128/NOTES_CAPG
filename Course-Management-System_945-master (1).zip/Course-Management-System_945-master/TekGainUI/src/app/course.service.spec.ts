import { TestBed } from '@angular/core/testing';

import { CourseService } from './course.service';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
describe('CourseService', () => {

  
// Fill the code  for unit testing




});
