export class Admission {

    constructor(public registrationId: string, public courseId: string,public associateId: string,public  fees: number,  public feedback:string,public rating:number) {  }
}

