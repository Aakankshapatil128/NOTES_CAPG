package com.cms.model;

import org.springframework.data.annotation.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Signup {
	@Id
	private String associateId;
	private String associateName;
	private String associateEmailId;
	private String username;
	private String password;
	private String role;
	private String associateAddress;
}