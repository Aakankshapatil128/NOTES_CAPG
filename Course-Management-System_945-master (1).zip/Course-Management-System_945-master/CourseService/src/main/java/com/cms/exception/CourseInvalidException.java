package com.cms.exception;
public class CourseInvalidException extends Exception {
	public CourseInvalidException(String message) {
		super(message);
	}
}